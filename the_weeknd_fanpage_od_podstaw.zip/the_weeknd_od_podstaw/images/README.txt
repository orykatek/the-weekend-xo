Tutaj możesz umieszczać własne zdjęcia galerii.
Przykład:
<img src="images/weeknd-01.jpg" alt="The Weeknd live">
Używaj tylko materiałów, do których masz prawa lub zgodę autora.